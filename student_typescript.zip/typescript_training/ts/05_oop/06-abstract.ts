// abstract class Laptop {

// 	public keyboard(): void{
// 		console.log("Laptop.keyboard");
// 	}

// 	public abstract mainboard(abc: string) : string;

// 	public chipset(): void{
// 		console.log("Laptop.chipset");
// 	}

// }

// class LaptopDell extends Laptop {
// 	public keyboard(): void{
// 		console.log("LaptopDell.keyboard");
// 	}

// 	public mainboard(): string{
// 		console.log("LaptopDell.mainboard");
// 		return "123";
// 	}
// }

// let laptopObj : LaptopDell = new LaptopDell();

// laptopObj.keyboard();
// laptopObj.mainboard();
// laptopObj.chipset();