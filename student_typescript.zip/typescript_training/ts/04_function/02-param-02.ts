/*
function totalLength(x: (string | any[]), y: (string[] | string) ) : number{
	return x.length + y.length;

}


// totalLength(['abc', 'def'], ['123']);
console.log(totalLength('abc', ['123']));					// 4
console.log(totalLength([1, "abc", "def"], ['123', "def"]));		// 5
console.log(totalLength([1, "abc", "def"], "123"));	// 3 + 3
*/