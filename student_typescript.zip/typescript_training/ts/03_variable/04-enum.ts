/*
// 100 created, 101 proccess, 102 finish
enum STATUS { created = 100, process = 900, finish = 500};

let todoStatus : STATUS = STATUS.finish;

console.log(todoStatus);
*/