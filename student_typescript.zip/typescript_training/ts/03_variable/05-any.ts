/*
let mVariable: any = 4;

mVariable = "ABC";
mVariable = true;

let mArray: any[] = [1, true, "abc"];

console.log(mVariable);
console.log(mArray);

*/