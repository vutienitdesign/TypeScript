/*
let objOne: any = {};
console.log(objOne);

interface CourseInterface {
	name: string;
	time: string;
	free?: boolean;
}

let objTwo: CourseInterface;
objTwo = {
	name: "ES6",
	time: "5h"
};

let objThree: CourseInterface = {
	name: "Typescript",
	time: "10h",
	free: false
};
console.log(objTwo);
console.log(objThree);
*/