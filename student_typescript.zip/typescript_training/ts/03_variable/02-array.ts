/*
let arrNumber: Array<number> = [1, 5, 8];
let arrString: string[] = ["java", "android", "es6"];

console.log(arrNumber);
console.log(arrString);


console.log(arrString.push("typescript"));		// 4
console.log(arrString); // "java", "android", "es6", "typescript"
*/