/*
// Boolean
let free: boolean = true;
free = false;

// Number
let score: number = 10;

// String
let elm: string = "ABC";
elm = 'ABC 123';
elm = `Free: ${free} - Score: ${score}`;


console.log(free);
console.log(score);
console.log(elm);
*/