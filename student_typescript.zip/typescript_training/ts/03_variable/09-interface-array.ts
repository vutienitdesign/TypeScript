// // let course: string[] = ["es6", "typescript"];

// interface CourseList {
// 	[index: number]: number;
// }

// let course: CourseList = [1, 2];

// console.log(course); 