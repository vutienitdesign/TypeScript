/*
let x: [string, number, boolean];

x = ["abc", 10, true];

console.log(x);
*/