/*

function showInfo(): void{
	console.log("Hello void");
}

showInfo();

let abc:number;

*/