export class Abc {
	showInfo(): void {
		console.log("Abc.showInfo");
	}
}

export function printAbc() {
	console.log("Abc.printAbc");
}