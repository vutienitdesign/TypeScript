// class StudyGeneric {
// 	static printArray<T>(params: T[]) : void {
// 		console.log(params);
// 	}
// }
// StudyGeneric.printArray<number>([1, 2, 3, 5]);
// StudyGeneric.printArray<string>(["a", "bc", "def"]);
// StudyGeneric.printArray<any>([1, 2, 3, 5, "a", false, "bc", "def", true]);