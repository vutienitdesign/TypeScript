// Study 02
console.log('Hello TypeScript - Study 02');
