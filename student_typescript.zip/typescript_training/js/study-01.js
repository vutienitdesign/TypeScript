// Study 01
console.log('Hello TypeScript - Study 01');
