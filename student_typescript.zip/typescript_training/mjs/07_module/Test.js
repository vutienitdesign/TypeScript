"use strict";
const MModule = require("./MModule");
let obj = new MModule.Abc();
obj.showInfo();
console.log("123");
MModule.printAbc();
