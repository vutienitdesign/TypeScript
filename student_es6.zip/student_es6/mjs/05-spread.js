let courseWeb		= ["PHP", "Zend", "WordPres"];
let courseMobile	= ["Android", "IOS"];

let course = ["HTML", "jQuery", ...courseWeb, "Window Phone", ...courseMobile];
// "HTML", "jQuery", "PHP", "Zend", "WordPres", "Window Phone", "Android", "IOS"
console.log(course);