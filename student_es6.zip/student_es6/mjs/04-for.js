let todoArr = [
	"Play football",
	"Coding",
	"Study Typescript"
];

/* ==================== CASE 01 ==================== */
/*
let length	= todoArr.length;
for(let i = 0; i < length; i++){
	console.log(todoArr[i]);
}
*/

/* ==================== CASE 02 ==================== */
/*
for (let index in todoArr) {
	console.log(index + ": " + todoArr[index]);
}
*/

/* ==================== CASE 03 ==================== */
/*
for (let todo of todoArr) {
	console.log(todo);
}
*/

/* ==================== CASE 04 ==================== */
/*
let todoObj = {
	id: 169,
	name: "Play football",
	status: false
};


for (let index in todoObj) {
	console.log(index + ": " + todoObj[index]);
}
*/