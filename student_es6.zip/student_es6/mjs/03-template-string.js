let elm = document.getElementById("mContent");
elm.style.color	= "#0174DF";



/* ==================== EXAMPLE 01 ==================== */


/*
let name	= "Typescript 123";
let price	= 25;

elm.innerHTML	= `<div>Course name: <b>${name}</b>, 
						price: <b style="color: red">${price} USD</b>
					</div>`;
*/

/* ==================== EXAMPLE 02 ==================== */

/*
let todo = {
	id: 169,
	name: "Play football",
	status: false
};

elm.innerHTML	= `<div id="todo-id-${todo.id}">
						<i class="${ todo.status == true ? "hidden" : ""} glyphicon glyphicon-ok"></i>
						<span class="name">${todo.name}</span>
					</div>`;
*/