/*
const COURSE_NAME = "Typescript";

console.log(COURSE_NAME);
*/